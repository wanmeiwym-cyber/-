const sections = [...document.querySelectorAll("[data-scroll-section]")];
const header = document.querySelector(".site-header");
const meterCurrent = document.querySelector(".meter-current");
const meterProgress = document.querySelector(".meter-line span");
const cursorDot = document.querySelector(".cursor-dot");
const cursorRing = document.querySelector(".cursor-ring");
const interactiveElements = document.querySelectorAll("a, button");
const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

let activeIndex = 0;
let isTransitioning = false;
let wheelDistance = 0;
let wheelResetTimer;

if ("scrollRestoration" in window.history) {
  window.history.scrollRestoration = "manual";
}

if (!window.location.hash) {
  window.scrollTo(0, 0);
}

window.addEventListener("pageshow", () => {
  if (!window.location.hash) {
    window.scrollTo(0, 0);
  }
});

function setActive(index) {
  if (index < 0 || index >= sections.length || isTransitioning) return;

  activeIndex = index;
  isTransitioning = true;

  sections[index].scrollIntoView({
    behavior: reduceMotion ? "auto" : "smooth",
    block: "start",
  });

  window.setTimeout(
    () => {
      isTransitioning = false;
    },
    reduceMotion ? 0 : 1050,
  );
}

function syncInterface(index) {
  const section = sections[index];
  if (!section) return;

  activeIndex = index;
  meterCurrent.textContent = String(index + 1).padStart(2, "0");
  meterProgress.style.height = `${((index + 1) / sections.length) * 100}%`;
  header.dataset.theme = section.dataset.theme || "light";
}

function findCurrentSection() {
  let closestIndex = 0;
  let closestDistance = Number.POSITIVE_INFINITY;

  sections.forEach((section, index) => {
    const distance = Math.abs(section.getBoundingClientRect().top);
    if (distance < closestDistance) {
      closestDistance = distance;
      closestIndex = index;
    }
  });

  return closestIndex;
}

const revealObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      entry.target.classList.toggle("is-visible", entry.isIntersecting);
    });
  },
  {
    rootMargin: "-8% 0px -8% 0px",
    threshold: 0.34,
  },
);

document.querySelectorAll(".panel").forEach((element) => {
  revealObserver.observe(element);
});

const pageObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting && entry.intersectionRatio >= 0.52) {
        syncInterface(sections.indexOf(entry.target));
      }
    });
  },
  {
    threshold: [0.52, 0.7],
  },
);

sections.forEach((section) => pageObserver.observe(section));

const heroSlides = [...document.querySelectorAll(".hero-slide")];
let heroSlideIndex = 0;
let heroSlideTimer;

function advanceHeroSlide() {
  if (heroSlides.length < 2 || document.hidden) return;

  heroSlides[heroSlideIndex].classList.remove("is-active");
  heroSlideIndex = (heroSlideIndex + 1) % heroSlides.length;
  heroSlides[heroSlideIndex].classList.add("is-active");
}

if (!reduceMotion && heroSlides.length > 1) {
  heroSlideTimer = window.setInterval(advanceHeroSlide, 7200);
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      window.clearInterval(heroSlideTimer);
    } else {
      heroSlideTimer = window.setInterval(advanceHeroSlide, 7200);
    }
  });
}

window.addEventListener(
  "wheel",
  (event) => {
    if (event.ctrlKey || reduceMotion) return;

    event.preventDefault();
    wheelDistance += event.deltaY;
    window.clearTimeout(wheelResetTimer);
    wheelResetTimer = window.setTimeout(() => {
      wheelDistance = 0;
    }, 180);

    if (isTransitioning || Math.abs(wheelDistance) < 24) return;

    const direction = wheelDistance > 0 ? 1 : -1;
    wheelDistance = 0;
    setActive(activeIndex + direction);
  },
  { passive: false },
);

window.addEventListener("keydown", (event) => {
  const key = event.key;

  if (["ArrowDown", "PageDown", " "].includes(key)) {
    event.preventDefault();
    setActive(activeIndex + 1);
  }

  if (["ArrowUp", "PageUp"].includes(key)) {
    event.preventDefault();
    setActive(activeIndex - 1);
  }

  if (key === "Home") {
    event.preventDefault();
    setActive(0);
  }

  if (key === "End") {
    event.preventDefault();
    setActive(sections.length - 1);
  }
});

document.querySelectorAll('a[href^="#"]').forEach((link) => {
  link.addEventListener("click", (event) => {
    const href = link.getAttribute("href");

    if (href === "#") {
      event.preventDefault();
      return;
    }

    const target = document.querySelector(href);
    const targetIndex = sections.indexOf(target);

    if (targetIndex === -1) return;

    event.preventDefault();
    setActive(targetIndex);
  });
});

const canUseCursor = window.matchMedia("(hover: hover) and (pointer: fine)").matches;

if (canUseCursor) {
  let pointerX = window.innerWidth / 2;
  let pointerY = window.innerHeight / 2;
  let ringX = pointerX;
  let ringY = pointerY;

  window.addEventListener("pointermove", (event) => {
    document.body.classList.add("has-cursor");
    pointerX = event.clientX;
    pointerY = event.clientY;
    cursorDot.style.transform = `translate(${pointerX}px, ${pointerY}px) translate(-50%, -50%)`;
  });

  function renderCursor() {
    ringX += (pointerX - ringX) * 0.16;
    ringY += (pointerY - ringY) * 0.16;
    cursorRing.style.transform = `translate(${ringX}px, ${ringY}px) translate(-50%, -50%)`;
    window.requestAnimationFrame(renderCursor);
  }

  renderCursor();

  interactiveElements.forEach((element) => {
    element.addEventListener("mouseenter", () => {
      document.body.classList.add("cursor-active");
    });

    element.addEventListener("mouseleave", () => {
      document.body.classList.remove("cursor-active");
    });
  });
}

window.addEventListener("scroll", () => {
  window.requestAnimationFrame(() => syncInterface(findCurrentSection()));
});

syncInterface(0);
