const sections = [...document.querySelectorAll("[data-scroll-section]")];
const header = document.querySelector(".site-header");
const meterCurrent = document.querySelector(".meter-current");
const meterProgress = document.querySelector(".meter-line span");
const cursorDot = document.querySelector(".cursor-dot");
const cursorRing = document.querySelector(".cursor-ring");
const interactiveElements = document.querySelectorAll("a, button");
const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
const introSection = document.querySelector(".intro-orb");

let activeIndex = 0;
let isTransitioning = false;
let wheelDistance = 0;
let wheelResetTimer;

if ("scrollRestoration" in window.history) {
  window.history.scrollRestoration = "manual";
}

if (!window.location.hash) {
  window.scrollTo(0, 0);
}

window.addEventListener("pageshow", () => {
  if (!window.location.hash) {
    window.scrollTo(0, 0);
  }
});

function setActive(index) {
  if (index < 0 || index >= sections.length || isTransitioning) return;

  if (index === 0) {
    introSection.classList.remove("is-leaving");
  }

  if (activeIndex === 0 && index === 1 && !reduceMotion) {
    activeIndex = 1;
    isTransitioning = true;
    introSection.classList.add("is-leaving");

    window.setTimeout(() => {
      sections[1].scrollIntoView({ behavior: "smooth", block: "start" });
    }, 820);

    window.setTimeout(() => {
      isTransitioning = false;
    }, 1850);
    return;
  }

  activeIndex = index;
  isTransitioning = true;

  sections[index].scrollIntoView({
    behavior: reduceMotion ? "auto" : "smooth",
    block: "start",
  });

  window.setTimeout(
    () => {
      isTransitioning = false;
    },
    reduceMotion ? 0 : 1050,
  );
}

function syncInterface(index) {
  const section = sections[index];
  if (!section) return;

  activeIndex = index;
  meterCurrent.textContent = String(index + 1).padStart(2, "0");
  meterProgress.style.height = `${((index + 1) / sections.length) * 100}%`;
  header.dataset.theme = section.dataset.theme || "light";

  if (index === 0 && !isTransitioning) {
    introSection.classList.remove("is-leaving");
  }
}

function findCurrentSection() {
  let closestIndex = 0;
  let closestDistance = Number.POSITIVE_INFINITY;

  sections.forEach((section, index) => {
    const distance = Math.abs(section.getBoundingClientRect().top);
    if (distance < closestDistance) {
      closestDistance = distance;
      closestIndex = index;
    }
  });

  return closestIndex;
}

const revealObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      entry.target.classList.toggle("is-visible", entry.isIntersecting);
    });
  },
  {
    rootMargin: "-8% 0px -8% 0px",
    threshold: 0.34,
  },
);

document.querySelectorAll(".panel").forEach((element) => {
  revealObserver.observe(element);
});

const pageObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting && entry.intersectionRatio >= 0.52) {
        syncInterface(sections.indexOf(entry.target));
      }
    });
  },
  {
    threshold: [0.52, 0.7],
  },
);

sections.forEach((section) => pageObserver.observe(section));

const orbStage = document.querySelector(".orb-stage");
const orbItems = [...document.querySelectorAll(".orb-item")];
const goldenAngle = Math.PI * (3 - Math.sqrt(5));
const orbPoints = orbItems.map((_, index) => {
  const y = 1 - (index / Math.max(orbItems.length - 1, 1)) * 2;
  const radius = Math.sqrt(Math.max(0, 1 - y * y));
  const angle = goldenAngle * index;

  return {
    x: Math.cos(angle) * radius,
    y,
    z: Math.sin(angle) * radius,
  };
});

let orbPointerX = 0;
let orbPointerY = 0;
let orbAnimationTime = 0;
let orbLastFrame = 0;
let orbPaused = false;

orbItems.forEach((item) => {
  item.addEventListener("mouseenter", () => {
    orbPaused = true;
  });
  item.addEventListener("mouseleave", () => {
    orbPaused = false;
  });
  item.addEventListener("focus", () => {
    orbPaused = true;
  });
  item.addEventListener("blur", () => {
    orbPaused = false;
  });
});

window.addEventListener("pointermove", (event) => {
  orbPointerX = (event.clientX / window.innerWidth - 0.5) * 2;
  orbPointerY = (event.clientY / window.innerHeight - 0.5) * 2;
});

function renderOrb(now) {
  if (!orbLastFrame) orbLastFrame = now;

  const delta = Math.min((now - orbLastFrame) / 1000, 0.05);
  orbLastFrame = now;
  if (!orbPaused) orbAnimationTime += delta;

  const time = orbAnimationTime;
  const stageRect = orbStage.getBoundingClientRect();
  const radius = Math.min(stageRect.width, stageRect.height) * 0.33;
  const rotationY = time * 0.14 + orbPointerX * 0.14;
  const rotationX = -0.08 + Math.sin(time * 0.22) * 0.09 + orbPointerY * 0.06;
  const sinY = Math.sin(rotationY);
  const cosY = Math.cos(rotationY);
  const sinX = Math.sin(rotationX);
  const cosX = Math.cos(rotationX);

  orbItems.forEach((item, index) => {
    const point = orbPoints[index];
    const y1 = point.y * cosX - point.z * sinX;
    const z1 = point.y * sinX + point.z * cosX;
    const x2 = point.x * cosY - z1 * sinY;
    const z2 = point.x * sinY + z1 * cosY;
    const depth = (z2 + 1) / 2;
    const perspective = 0.72 + depth * 0.5;
    const xPosition = x2 * radius * 1.1;
    const yPosition = y1 * radius;
    const blur = (1 - depth) * 1.45;

    item.style.zIndex = String(Math.round(depth * 100));
    item.style.opacity = String(0.25 + depth * 0.75);
    item.style.filter = `blur(${blur.toFixed(2)}px) saturate(${(0.72 + depth * 0.18).toFixed(2)})`;
    item.style.transform = `translate(-50%, -50%) translate3d(${xPosition.toFixed(2)}px, ${yPosition.toFixed(2)}px, 0) scale(${perspective.toFixed(3)})`;
  });

  window.requestAnimationFrame(renderOrb);
}

if (!reduceMotion && orbItems.length) {
  window.requestAnimationFrame(renderOrb);
}

const heroSlides = [...document.querySelectorAll(".hero-slide")];
let heroSlideIndex = 0;
let heroSlideTimer;

function advanceHeroSlide() {
  if (heroSlides.length < 2 || document.hidden) return;

  heroSlides[heroSlideIndex].classList.remove("is-active");
  heroSlideIndex = (heroSlideIndex + 1) % heroSlides.length;
  heroSlides[heroSlideIndex].classList.add("is-active");
}

if (!reduceMotion && heroSlides.length > 1) {
  heroSlideTimer = window.setInterval(advanceHeroSlide, 7200);
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      window.clearInterval(heroSlideTimer);
    } else {
      heroSlideTimer = window.setInterval(advanceHeroSlide, 7200);
    }
  });
}

window.addEventListener(
  "wheel",
  (event) => {
    if (event.ctrlKey || reduceMotion) return;

    event.preventDefault();
    wheelDistance += event.deltaY;
    window.clearTimeout(wheelResetTimer);
    wheelResetTimer = window.setTimeout(() => {
      wheelDistance = 0;
    }, 180);

    if (isTransitioning || Math.abs(wheelDistance) < 24) return;

    const direction = wheelDistance > 0 ? 1 : -1;
    wheelDistance = 0;
    setActive(activeIndex + direction);
  },
  { passive: false },
);

window.addEventListener("keydown", (event) => {
  const key = event.key;

  if (["ArrowDown", "PageDown", " "].includes(key)) {
    event.preventDefault();
    setActive(activeIndex + 1);
  }

  if (["ArrowUp", "PageUp"].includes(key)) {
    event.preventDefault();
    setActive(activeIndex - 1);
  }

  if (key === "Home") {
    event.preventDefault();
    setActive(0);
  }

  if (key === "End") {
    event.preventDefault();
    setActive(sections.length - 1);
  }
});

document.querySelectorAll('a[href^="#"]').forEach((link) => {
  link.addEventListener("click", (event) => {
    const href = link.getAttribute("href");

    if (href === "#") {
      event.preventDefault();
      return;
    }

    const target = document.querySelector(href);
    const targetIndex = sections.indexOf(target);

    if (targetIndex === -1) return;

    event.preventDefault();
    setActive(targetIndex);
  });
});

const canUseCursor = window.matchMedia("(hover: hover) and (pointer: fine)").matches;

if (canUseCursor) {
  let pointerX = window.innerWidth / 2;
  let pointerY = window.innerHeight / 2;
  let ringX = pointerX;
  let ringY = pointerY;

  window.addEventListener("pointermove", (event) => {
    document.body.classList.add("has-cursor");
    pointerX = event.clientX;
    pointerY = event.clientY;
    cursorDot.style.transform = `translate(${pointerX}px, ${pointerY}px) translate(-50%, -50%)`;
  });

  function renderCursor() {
    ringX += (pointerX - ringX) * 0.16;
    ringY += (pointerY - ringY) * 0.16;
    cursorRing.style.transform = `translate(${ringX}px, ${ringY}px) translate(-50%, -50%)`;
    window.requestAnimationFrame(renderCursor);
  }

  renderCursor();

  interactiveElements.forEach((element) => {
    element.addEventListener("mouseenter", () => {
      document.body.classList.add("cursor-active");
    });

    element.addEventListener("mouseleave", () => {
      document.body.classList.remove("cursor-active");
    });
  });
}

window.addEventListener("scroll", () => {
  window.requestAnimationFrame(() => syncInterface(findCurrentSection()));
});

syncInterface(0);
