const projects = {
  sola: {
    title: "SOLA",
    subtitle:
      "以日光、海岸与植物气息为线索，建立克制、自然且具有艺术感的香氛品牌视觉。",
    category: "FRAGRANCE BRANDING / PERSONAL CONCEPT PROJECT",
    hero: "./assets/sola/hero.webp",
    intro:
      "SOLA 是一套自主发起的香氛品牌视觉企划。项目围绕日光、海岸和植物展开，通过暖色摄影、编辑式版式和留白建立品牌气质，并将视觉语言延展到包装、Campaign、社交媒体与电商场景。",
    year: "2026",
    role: "Personal Concept Project / 品牌视觉设计",
    scope: "品牌主视觉、品牌理念、Moodboard、香水包装、Campaign 与社交电商应用",
    gallery: [
      {
        src: "./assets/sola/moodboard.webp",
        caption: "Brand philosophy / Moodboard",
        layout: "wide",
      },
      {
        src: "./assets/sola/floral.webp",
        caption: "Radiant floral fragrance",
        layout: "half",
      },
      {
        src: "./assets/sola/coast.webp",
        caption: "Sunlit coast campaign",
        layout: "half",
      },
      {
        src: "./assets/sola/triptych.webp",
        caption: "Sunlit petals triptych",
        layout: "poster",
      },
    ],
  },
  mora: {
    title: "MORA 沐白",
    subtitle:
      "以蓝色、奶油黄和白色建立年轻、清新且具有商业传播力的口腔护理品牌。",
    category: "ORAL CARE BRANDING / PERSONAL CONCEPT PROJECT",
    hero: "./assets/mora/system.webp",
    heroLayout: "poster",
    intro:
      "MORA 沐白是一套自主发起的口腔护理品牌视觉企划。项目以清新晨间场景为起点，构建 Logo、视觉识别、原创包装造型、Campaign 海报和电商社交应用，形成轻松、现代而有商业辨识度的品牌系统。",
    year: "2026",
    role: "Personal Concept Project / 品牌视觉设计",
    scope: "品牌主视觉、Logo 与视觉识别、包装、Campaign、电商与社交媒体应用",
    gallery: [
      {
        src: "./assets/mora/proposal.webp",
        caption: "Brand visual proposal",
        layout: "half",
      },
      {
        src: "./assets/mora/campaign.webp",
        caption: "Fresh morning campaign",
        layout: "half",
      },
    ],
  },
  "eastern-ghost": {
    title: "东方幽魂",
    subtitle: "从东方志怪意象出发，建立角色、三维表现与视觉应用完整的 IP 系统。",
    category: "IP IMAGE / CHARACTER DESIGN",
    hero: "./assets/cover-east-ghost.webp",
    intro:
      "项目以东方文化中的幽魂意象为线索，通过角色比例、材质与符号系统建立具有辨识度的形象。视觉语言强调神秘感与当代感的平衡，并延展至三维渲染、海报和应用场景。",
    year: "2026",
    role: "IP 形象设计 / 三维呈现",
    scope: "角色设定、三视图、视觉规范、海报与衍生应用",
    gallery: [
      {
        src: "./assets/detail/east-board.webp",
        caption: "IP visual system / Application board",
        layout: "wide",
      },
      {
        src: "./assets/detail/east-board-02.webp",
        caption: "Complete visual board",
        layout: "poster",
      },
      {
        src: "./assets/hero.webp",
        caption: "Primary character view",
        layout: "half",
      },
      {
        src: "./assets/eastern-ghost.webp",
        caption: "Character presentation",
        layout: "wide",
      },
    ],
  },
  "maritime-ip": {
    title: "海上丝绸之路",
    subtitle: "以海丝文化为根基，将历史主题转译为年轻、清晰且可延展的 IP 视觉。",
    category: "IP IDENTITY / CULTURAL DESIGN",
    hero: "./assets/maritime-999.webp",
    heroLayout: "poster",
    intro:
      "以海丝文化中的航线、器物与交流意象为核心，构建具有文化识别度的 IP 形象与辅助图形。整体视觉兼顾传统主题的深度与当代传播的轻盈感。",
    year: "2026",
    role: "IP 形象与视觉系统设计",
    scope: "角色设定、Logo 系统、品牌延展与展示海报",
    gallery: [
      {
        src: "./assets/detail/maritime-01.webp",
        caption: "IP world building",
        layout: "poster",
      },
      {
        src: "./assets/detail/maritime-02.webp",
        caption: "Character system",
        layout: "poster",
      },
      {
        src: "./assets/detail/maritime-03.webp",
        caption: "Primary visual page",
        layout: "poster",
      },
      {
        src: "./assets/detail/maritime-04.webp",
        caption: "Character application",
        layout: "poster",
      },
      {
        src: "./assets/detail/maritime-05.webp",
        caption: "Visual presentation",
        layout: "poster",
      },
    ],
  },
  packaging: {
    title: "包装设计",
    subtitle: "从结构与陈列出发，让包装在材质、图形和系列关系中形成清晰识别。",
    category: "PACKAGING / VISUAL SYSTEM",
    hero: "./assets/packaging.webp",
    intro:
      "项目关注包装在真实使用场景中的视觉秩序。通过版式、材质和结构关系建立系列感，并让信息层级在货架与陈列环境中保持清晰。",
    year: "2025—2026",
    role: "包装视觉与版式设计",
    scope: "系列包装、图形系统与终端呈现",
    gallery: [
      {
        src: "./assets/packaging.webp",
        caption: "Packaging study 01",
        layout: "poster",
      },
      {
        src: "./assets/detail/packaging-02.webp",
        caption: "Packaging study 02",
        layout: "poster",
      },
      {
        src: "./assets/detail/packaging-detail.webp",
        caption: "Series and shelf presentation",
        layout: "wide",
      },
    ],
  },
  "culture-wall": {
    title: "乡绘 2026",
    subtitle: "百千万三下乡项目负责人，以墙绘连接地域文化、公共空间与社区日常。",
    category: "CULTURAL WALL / 百千万三下乡",
    hero: "./assets/culture-wall-rotated.webp",
    intro:
      "作为百千万三下乡项目负责人，我主导在地文化调研、内容规划和整体视觉落地。作品将地域记忆转译为可进入的公共画面，并兼顾空间尺度、观看距离与环境关系。",
    year: "2026",
    role: "百千万三下乡项目负责人",
    scope: "文化调研、内容规划、墙绘设计与现场落地",
    gallery: [
      {
        src: "./assets/culture-wall-rotated.webp",
        caption: "Project lead / Overall visual",
        layout: "wide",
      },
      {
        src: "./assets/detail/culture-1.webp",
        caption: "Cultural wall detail 01",
        layout: "half",
      },
      {
        src: "./assets/detail/culture-2.webp",
        caption: "Cultural wall detail 02",
        layout: "half",
      },
      {
        src: "./assets/detail/culture-4.webp",
        caption: "Cultural wall detail 03",
        layout: "half",
      },
      {
        src: "./assets/detail/culture-5.webp",
        caption: "Cultural wall detail 04",
        layout: "half",
      },
      {
        src: "./assets/detail/culture-6.webp",
        caption: "Public space integration",
        layout: "wide",
      },
    ],
  },
  illustration: {
    title: "数码插画",
    subtitle: "三组数字绘画作品，从色彩、角色与叙事场景建立不同的视觉情绪。",
    category: "DIGITAL ILLUSTRATION / VISUAL STORYTELLING",
    hero: "./assets/illustration-2.webp",
    intro:
      "项目以数字绘画为媒介，围绕人物、空间与情绪展开实验。三张作品使用不同的色彩关系和构图方式，呈现从角色塑造到场景叙事的连续表达。",
    year: "2025",
    role: "插画与视觉叙事",
    scope: "角色设计、场景设计与数字绘画",
    gallery: [
      {
        src: "./assets/illustration-1.webp",
        caption: "Illustration study 01",
        layout: "third",
      },
      {
        src: "./assets/illustration-2.webp",
        caption: "Illustration study 02",
        layout: "third",
      },
      {
        src: "./assets/illustration-3.webp",
        caption: "Illustration study 03",
        layout: "third",
      },
    ],
  },
  "product-design": {
    title: "斗拱·声境",
    subtitle: "从传统斗拱的结构秩序出发，将声音互动与文化体验转化为可感知的产品装置。",
    category: "PRODUCT DESIGN / INTERACTION",
    hero: "./assets/product-design.webp",
    heroLayout: "poster",
    intro:
      "项目提取斗拱的层叠、支撑与穿插关系，将其转译为可互动的产品体验。声音作为连接结构与情绪的媒介，让文化内容从静态展示进入可触摸、可感知的使用场景。",
    year: "2026",
    role: "产品与交互体验设计",
    scope: "概念发展、造型设计、交互逻辑与展示系统",
    gallery: [
      {
        src: "./assets/detail/product-1.webp",
        caption: "Design concept",
        layout: "poster",
      },
      {
        src: "./assets/detail/product-2.webp",
        caption: "Form and structure",
        layout: "poster",
      },
      {
        src: "./assets/detail/product-3.webp",
        caption: "Interactive experience",
        layout: "poster",
      },
      {
        src: "./assets/detail/product-4.webp",
        caption: "Product application",
        layout: "poster",
      },
    ],
  },
};

const projectOrder = [
  "sola",
  "mora",
  "eastern-ghost",
  "maritime-ip",
  "packaging",
  "culture-wall",
  "illustration",
  "product-design",
];

const params = new URLSearchParams(window.location.search);
const key = params.get("project");
const project = projects[key] || projects["eastern-ghost"];
const projectIndex = Math.max(projectOrder.indexOf(key), 0);
const nextKey = projectOrder[(projectIndex + 1) % projectOrder.length];
const previousKey =
  projectOrder[(projectIndex - 1 + projectOrder.length) % projectOrder.length];

document.title = `${project.title} — WANG YAMEI`;

const gallery = project.gallery
  .map(
    (item) => `
      <figure class="case-figure case-figure--${item.layout} case-reveal">
        <img src="${item.src}" alt="${project.title} / ${item.caption}" loading="lazy" />
        <figcaption>${item.caption}</figcaption>
      </figure>
    `,
  )
  .join("");

document.querySelector("#project-detail").innerHTML = `
  <section class="case-hero${project.heroLayout ? ` case-hero--${project.heroLayout}` : ""}">
    <div class="case-hero-media">
      <img src="${project.hero}" alt="${project.title}" />
    </div>
    <div class="case-hero-shade"></div>
    <div class="case-hero-content">
      <p class="case-eyebrow">${project.category}</p>
      <h1>${project.title}</h1>
      <p class="case-hero-subtitle">${project.subtitle}</p>
    </div>
  </section>

  <div class="case-body">
    <section class="case-intro">
      <p class="case-label case-reveal">PROJECT OVERVIEW</p>
      <p class="case-intro-copy case-reveal">${project.intro}</p>
      <div class="case-meta case-reveal">
        <div class="case-meta-item"><span>Year</span><p>${project.year}</p></div>
        <div class="case-meta-item"><span>Role</span><p>${project.role}</p></div>
        <div class="case-meta-item"><span>Scope</span><p>${project.scope}</p></div>
      </div>
    </section>

    <section class="case-gallery">${gallery}</section>
  </div>

  <nav class="case-next" aria-label="项目导航">
    <a href="./project.html?project=${previousKey}">
      <small>Previous</small>
      <span>${projects[previousKey].title}</span>
    </a>
    <a href="./project.html?project=${nextKey}">
      <small>Next project</small>
      <span>${projects[nextKey].title}</span>
    </a>
  </nav>
`;

const revealObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) entry.target.classList.add("is-visible");
    });
  },
  {
    rootMargin: "-8% 0px -8% 0px",
    threshold: 0.18,
  },
);

document.querySelectorAll(".case-reveal").forEach((element) => {
  revealObserver.observe(element);
});
